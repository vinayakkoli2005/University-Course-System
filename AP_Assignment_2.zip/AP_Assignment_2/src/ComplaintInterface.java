public interface ComplaintInterface {
    void submitComplaint(String Student_name,String description);
    void viewComplaintStatus();
    void HandleComplaint();
}
